# Dataset: heart.csv

# Columns: Age, Sex, ChestPainType, RestingBP, Cholesterol, FastingBS,
#          RestingECG, MaxHR, ExerciseAngina, Oldpeak, ST_Slope, HeartDisease

# Units used in this code:
# Unit 1  -> Data preprocessing + EDA
# Unit 2  -> Regression (Multiple Linear Regression)
# Unit 3  -> Classification (Logistic Regression, KNN, SVM)
# Unit 4  -> Clustering (K-Means, Elbow Method)
# Unit 5  -> Dimensionality Reduction (PCA) + Neural Network (MLP)
# Unit 6  -> Model Evaluation using K-Fold Cross-Validation

# We will create 6 objectives:
# Objective 1 (Unit 1): Data preprocessing and EDA
# Objective 2 (Unit 2): Regression – Predict Cholesterol
# Objective 3 (Unit 3): Classification – Predict HeartDisease using multiple models
# Objective 4 (Unit 4): K-Means clustering of patients into risk-based groups
# Objective 5 (Unit 5): PCA + MLP – Predict HeartDisease on reduced features
# Objective 6 (Unit 6): K-Fold Cross-Validation for model performance comparison


#Step 1: Library
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score,accuracy_score, confusion_matrix, classification_report

from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import KFold, cross_val_score

# ==========================
# OBJECTIVE 1 – UNIT 1
# DATA PREPROCESSING + EDA
# ==========================

# What are we predicting?
#   • Here we are not predicting anything, we are cleaning and understanding the data.
# What problem are we solving?
#   • Make the heart dataset ready for modelling by handling missing values, duplicates and outliers.
# Why?
#   • Clean and well-understood data improves the quality of all further models.
# Which Algorithms & Topics use ?
#   • Data preprocessing, handling missing values, removing duplicates, outlier detection (IQR),
#     basic plots like bar plot, box plot, count plot.

#Step 2: Load dataset 
df = pd.read_csv("heart.csv")

print("\n==== BASIC INFO (OBJECTIVE 1) ====")
print("Shape: ", df.shape)        # no. of rows and columns
print("\nColumns:\n", df.columns)
print("\nData Types:\n", df.dtypes)
print("\nFirst 5 rows:\n", df.head())
print("\nBasic Stats (numeric):\n", df.describe())

#Step 3: Missing values analysis
missing_counts = df.isna().sum().sort_values(ascending=False)
print("\nMissing Values per Column:\n", missing_counts)

#Plot missing values
plt.figure(figsize=(8,4))
missing_counts.plot(kind="bar")
plt.title("Missing Values per Column")
plt.xlabel("Columns")
plt.ylabel("Count")
plt.tight_layout()
plt.show()

#Step 4: Duplicate rows detection and removal
before = df.shape[0]
df = df.drop_duplicates()
after = df.shape[0]
print(f"\nRemoved {before - after} duplicate rows. New Shape: {df.shape}")

#Step 5: Handling missing values
#Separate numeric and categorical columns
num_cols = df.select_dtypes(include=[np.number]).columns.tolist()
cat_cols = df.select_dtypes(include=["object"]).columns.tolist()

print("\nNumeric Columns:", num_cols)
print("Categorical Columns:", cat_cols)

#Numerical -> fill with median
for c in num_cols:
    if df[c].isna().any():
        med = df[c].median()
        df[c].fillna(med, inplace=True)

#Categorical -> fill with mode
for c in cat_cols:
    if df[c].isna().any():
        mode_val = df[c].mode(dropna=True)
        if len(mode_val) > 0:
            df[c].fillna(mode_val[0], inplace=True)
        else:
            df[c].fillna("Unknown", inplace=True)

print("\nMissing values after imputation:\n", df.isna().sum())

#Step 6: Outlier detection using boxplot (example on Cholesterol)
q1 = df["Cholesterol"].quantile(0.25)
q3 = df["Cholesterol"].quantile(0.75)
iqr = q3 - q1
lower = q1 - 1.5 * iqr
upper = q3 + 1.5 * iqr
print("\nOutlier bounds for Cholesterol using IQR:", lower, upper)

plt.figure(figsize=(6,4))
plt.boxplot(df["Cholesterol"].dropna(), vert=True)
plt.title("Boxplot: Cholesterol (Detect Outliers)")
plt.ylabel("Cholesterol")
plt.tight_layout()
plt.show()

#Step 7: Target distribution plot (HeartDisease)
plt.figure(figsize=(5,4))
df["HeartDisease"].value_counts().plot(kind="bar")
plt.title("Target Distribution: HeartDisease")
plt.xlabel("HeartDisease (0 = No, 1 = Yes)")
plt.ylabel("Count")
plt.tight_layout()
plt.show()

#Step 8: Simple relation plot (Age vs Cholesterol)
plt.figure(figsize=(6,4))
plt.scatter(df["Age"], df["Cholesterol"], color="purple")
plt.xlabel("Age")
plt.ylabel("Cholesterol")
plt.title("Age vs Cholesterol")
plt.grid(True)
plt.tight_layout()
plt.show()

#created processed dataset for models (encoding categorical columns)
df_processed = pd.get_dummies(df, columns=cat_cols, drop_first=True)
print("\nShape after encoding categorical columns:", df_processed.shape)



# ==========================
# OBJECTIVE 2 – UNIT 2
# REGRESSION – PREDICT CHOLESTEROL
# ==========================

# What are we predicting?
#   • Predict Cholesterol value of a patient from other health features.
# What problem are we solving?
#   • Given Age, RestingBP, MaxHR, etc. estimate Cholesterol level.
# Why?
#   • Helps doctors understand which factors are related to high Cholesterol.
# Which Algorithms & Topics use ?
#   • Multiple Linear Regression (Unit 2), train-test split, StandardScaler,
#     evaluation metrics: MAE, MSE, RMSE, R² and scatter plot with predicted vs actual.

#Step 1: Create X and y for Regression
X_reg = df_processed.drop(columns=["Cholesterol", "HeartDisease"])  # independent variables
y_reg = df_processed["Cholesterol"]                                 # dependent variable

#Step 2: Train-test split for regression
x_train_reg, x_test_reg, y_train_reg, y_test_reg = train_test_split(
    X_reg, y_reg, test_size=0.2, random_state=0
)

#Step 3: Feature scaling (Standardization)
scaler_reg = StandardScaler()
x_train_reg = scaler_reg.fit_transform(x_train_reg)
x_test_reg = scaler_reg.transform(x_test_reg)

#Step 4: Create and train Multiple Linear Regression model
reg_model = LinearRegression()
reg_model.fit(x_train_reg, y_train_reg)

#Step 5: Predict on test data
y_pred_reg = reg_model.predict(x_test_reg)

#Step 6: Evaluation metrics for regression
mae = mean_absolute_error(y_test_reg, y_pred_reg)
mse = mean_squared_error(y_test_reg, y_pred_reg)
rmse = np.sqrt(mse)
r2 = r2_score(y_test_reg, y_pred_reg)

print("\n==== OBJECTIVE 2: REGRESSION RESULTS ====")
print(f"MAE  : {mae:.4f}")
print(f"MSE  : {mse:.4f}")
print(f"RMSE : {rmse:.4f}")
print(f"R²   : {r2:.4f}")

#Step 7: Plot Actual vs Predicted Cholesterol
plt.figure(figsize=(6,5))
plt.scatter(y_test_reg, y_pred_reg, color="blue", label="Predicted vs Actual")
plt.xlabel("Actual Cholesterol")
plt.ylabel("Predicted Cholesterol")
plt.title("Objective 2: Actual vs Predicted Cholesterol")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.show()

# Extra small plot: Residuals (error)
residuals = y_test_reg - y_pred_reg
plt.figure(figsize=(6,4))
plt.hist(residuals, bins=20, color="orange")
plt.xlabel("Residual (Actual - Predicted)")
plt.ylabel("Frequency")
plt.title("Objective 2: Residual Distribution")
plt.tight_layout()
plt.show()



# ==========================
# OBJECTIVE 3 – UNIT 3
# CLASSIFICATION – MULTIPLE MODELS
# ==========================

# What are we predicting?
#   • Predict whether a patient has HeartDisease (0 or 1).
# What problem are we solving?
#   • Binary classification problem: HeartDisease vs No HeartDisease.
# Why?
#   • Helps in early detection of heart disease and decision making.
# Which Algorithms & Topics use ?
#   • Logistic Regression (Unit 2 but used for classification),
#     K-Nearest Neighbors (KNN) – lazy learning (Unit 3),
#     Support Vector Machine (SVM) – margin based classifier (Unit 3),
#     train-test split, StandardScaler, Accuracy, Confusion Matrix, Classification Report, plotting.

#Step 1: Create X and y for Classification
X_clf = df_processed.drop(columns=["HeartDisease"])  # independent variables
y_clf = df_processed["HeartDisease"]                 # dependent variable (0/1)

#Step 2: Train-test split for classification
x_train_clf, x_test_clf, y_train_clf, y_test_clf = train_test_split(
    X_clf, y_clf, test_size=0.2, random_state=42, stratify=y_clf
)

#Step 3: Feature scaling (Standardization)
scaler_clf = StandardScaler()
x_train_clf = scaler_clf.fit_transform(x_train_clf)
x_test_clf = scaler_clf.transform(x_test_clf)

#Step 4: Create 3 models – Logistic Regression, KNN, SVM
log_model = LogisticRegression(max_iter=300)
knn_model = KNeighborsClassifier(n_neighbors=5)
svm_model = SVC(kernel="rbf", C=1, gamma="scale")

models = {
    "Logistic Regression": log_model,
    "KNN (k=5)": knn_model,
    "SVM (RBF)": svm_model
}

#Step 5: Train, predict and evaluate each model
for name, model in models.items():
    print(f"\n==== {name} ====")
    model.fit(x_train_clf, y_train_clf)           # train
    y_pred = model.predict(x_test_clf)           # test predictions

    #Accuracy
    acc = accuracy_score(y_test_clf, y_pred)
    print("Accuracy:", acc)

    #Classification report
    print("\nClassification Report:\n", classification_report(y_test_clf, y_pred))

    #Confusion Matrix
    cm = confusion_matrix(y_test_clf, y_pred)
    print("Confusion Matrix:\n", cm)

    #Plot Confusion Matrix
    plt.figure(figsize=(5,4))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues")
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.title(f"Objective 3: Confusion Matrix - {name}")
    plt.tight_layout()
    plt.show()

#Extra: Plot comparison of model accuracies
model_names = []
accuracies = []

for name, model in models.items():
    y_pred = model.predict(x_test_clf)
    acc = accuracy_score(y_test_clf, y_pred)
    model_names.append(name)
    accuracies.append(acc)

plt.figure(figsize=(6,4))
plt.bar(model_names, accuracies, color="green")
plt.xlabel("Models")
plt.ylabel("Accuracy")
plt.title("Objective 3: Model Accuracy Comparison")
plt.tight_layout()
plt.show()




# ==========================
# OBJECTIVE 4 – UNIT 4
# CLUSTERING – K-MEANS ON PATIENTS
# ==========================

# What are we predicting?
#   • Here we are not predicting a label, we are grouping patients into clusters.
# What problem are we solving?
#   • Find natural groups of patients based on their health features (risk-based clusters).
# Why?
#   • Helps to identify similar types of patients (for example high risk vs low risk groups).
# Which Algorithms & Topics use ?
#   • K-Means clustering (Unit 4), elbow method to choose K, visualization of clusters.

#Step 1: Prepare data for clustering (remove target column)
X_cluster = df_processed.drop(columns=["HeartDisease"])

#Step 2: Scale features for clustering
scaler_cluster = StandardScaler()
X_cluster_scaled = scaler_cluster.fit_transform(X_cluster)

#Step 3: Elbow method to decide number of clusters (K)


inertias = []
K_values = range(1, 11)

for k in K_values:
    kmeans = KMeans(n_clusters=k, random_state=0, n_init=10)
    kmeans.fit(X_cluster_scaled)
    inertias.append(kmeans.inertia_)

#Plot elbow curve
plt.figure(figsize=(6,4))
plt.plot(K_values, inertias, marker="o")
plt.xlabel("Number of clusters (K)")
plt.ylabel("Inertia (Within cluster SSE)")
plt.title("Objective 4: Elbow Method for K-Means")
plt.grid(True)
plt.tight_layout()
plt.show()

#Step 4: Choose K (for example 3 here we have taken) and fit final K-Means model
k_opt = 3
kmeans_final = KMeans(n_clusters=k_opt, random_state=0, n_init=10)
cluster_labels = kmeans_final.fit_predict(X_cluster_scaled)

print("\n==== OBJECTIVE 4: CLUSTERING RESULTS ====")
unique_clusters, cluster_counts = np.unique(cluster_labels, return_counts=True)
for cid, count in zip(unique_clusters, cluster_counts):
    print("Cluster", cid, "->", count, "patients")

#Step 5: Visualize clusters in 2D using two features (Age and Cholesterol)
plt.figure(figsize=(6,5))
for cid in unique_clusters:
    plt.scatter(
        df.loc[cluster_labels == cid, "Age"],
        df.loc[cluster_labels == cid, "Cholesterol"],
        label=f"Cluster {cid}",
        alpha=0.7
    )
plt.xlabel("Age")
plt.ylabel("Cholesterol")
plt.title("Objective 4: K-Means Clusters (Age vs Cholesterol)")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()



# ==========================
# OBJECTIVE 5 – UNIT 5
# PCA + NEURAL NETWORK (MLP)
# ==========================

# What are we predicting?
#   • Predict HeartDisease (0 or 1) using a Neural Network on PCA-reduced features.
# What problem are we solving?
#   • Reduce the number of features using PCA and then apply a non-linear classifier.
# Why?
#   • PCA helps to remove noise and redundancy. MLP can learn complex patterns.
# Which Algorithms & Topics use ?
#   • Principal Component Analysis (PCA) – Unit 5
#   • Feedforward Neural Network – MLPClassifier – Unit 5



#Step 1: Use the same classification data (X_clf, y_clf)
#Scale features first
scaler_pca = StandardScaler()
X_clf_scaled = scaler_pca.fit_transform(X_clf)

#Step 2: Apply PCA (reduce to 2 components for easy visualization)
pca = PCA(n_components=2, random_state=0)
X_pca = pca.fit_transform(X_clf_scaled)

print("\nExplained variance ratio by PCA components:", pca.explained_variance_ratio_)

#Plot PCA components
plt.figure(figsize=(6,4))
plt.bar(["PC1", "PC2"], pca.explained_variance_ratio_)
plt.xlabel("Principal Components")
plt.ylabel("Explained Variance Ratio")
plt.title("Objective 5: PCA – Explained Variance")
plt.tight_layout()
plt.show()

#Step 3: Visualize data in 2D PCA space coloured by HeartDisease
plt.figure(figsize=(6,5))
plt.scatter(X_pca[y_clf == 0, 0], X_pca[y_clf == 0, 1], label="No HeartDisease (0)", alpha=0.7)
plt.scatter(X_pca[y_clf == 1, 0], X_pca[y_clf == 1, 1], label="HeartDisease (1)", alpha=0.7)
plt.xlabel("PC1")
plt.ylabel("PC2")
plt.title("Objective 5: PCA projection coloured by HeartDisease")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

#Step 4: Train-test split on PCA features
x_train_pca, x_test_pca, y_train_pca, y_test_pca = train_test_split(
    X_pca, y_clf, test_size=0.2, random_state=42, stratify=y_clf
)

#Step 5: Build and train MLP classifier
mlp_model = MLPClassifier(
    hidden_layer_sizes=(16, 8),   # two hidden layers
    activation="relu",
    solver="adam",
    max_iter=500,
    random_state=0
)

mlp_model.fit(x_train_pca, y_train_pca)

#Step 6: Evaluate MLP on test data
y_pred_mlp = mlp_model.predict(x_test_pca)
acc_mlp = accuracy_score(y_test_pca, y_pred_mlp)
cm_mlp = confusion_matrix(y_test_pca, y_pred_mlp)

print("\n==== OBJECTIVE 5: MLP ON PCA FEATURES ====")
print("Accuracy:", acc_mlp)
print("\nClassification Report:\n", classification_report(y_test_pca, y_pred_mlp))

#Plot confusion matrix
plt.figure(figsize=(5,4))
sns.heatmap(cm_mlp, annot=True, fmt="d", cmap="Reds")
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Objective 5: Confusion Matrix – MLP on PCA Features")
plt.tight_layout()
plt.show()



# ==========================
# OBJECTIVE 6 – UNIT 6
# MODEL EVALUATION WITH K-FOLD CROSS-VALIDATION
# ==========================

# What are we predicting?
#   • Again predicting HeartDisease (0 or 1) but focusing on model evaluation.
# What problem are we solving?
#   • Check how stable and reliable our models are using K-Fold cross-validation.
# Why?
#   • Single train-test split may give lucky/unlucky results. Cross-validation gives better estimate.
# Which Algorithms & Topics use ?
#   • K-Fold cross-validation (Unit 6)
#   • Evaluate Logistic Regression and SVM using mean accuracy over folds.


#Step 1: Use same scaled classification data (X_clf_scaled from Objective 5)
#Two models for comparison
log_cv_model = LogisticRegression(max_iter=300)
svm_cv_model = SVC(kernel="rbf", C=1, gamma="scale")

#Step 2: Define 5-fold cross-validation
kfold = KFold(n_splits=5, shuffle=True, random_state=0)

#Step 3: Cross-validation for Logistic Regression
log_cv_scores = cross_val_score(log_cv_model, X_clf_scaled, y_clf, cv=kfold, scoring="accuracy")
print("\n==== OBJECTIVE 6: CROSS-VALIDATION RESULTS ====")
print("Logistic Regression CV Accuracies:", log_cv_scores)
print("Logistic Regression Mean Accuracy:", log_cv_scores.mean())

#Step 4: Cross-validation for SVM
svm_cv_scores = cross_val_score(svm_cv_model, X_clf_scaled, y_clf, cv=kfold, scoring="accuracy")
print("\nSVM CV Accuracies:", svm_cv_scores)
print("SVM Mean Accuracy:", svm_cv_scores.mean())

#Step 5: Plot CV accuracy comparison
plt.figure(figsize=(6,4))
models_cv = ["Logistic Regression", "SVM"]
mean_scores = [log_cv_scores.mean(), svm_cv_scores.mean()]
plt.bar(models_cv, mean_scores, color=["skyblue", "salmon"])
plt.ylabel("Mean CV Accuracy")
plt.title("Objective 6: Cross-Validation Accuracy Comparison")
plt.tight_layout()
plt.show()


